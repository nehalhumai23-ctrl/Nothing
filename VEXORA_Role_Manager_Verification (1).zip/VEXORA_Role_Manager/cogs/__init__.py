"""VEXORA bot extensions."""
