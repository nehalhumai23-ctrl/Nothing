# VEXORA HUB — Role Manager Bot

A small, runnable `discord.py 2.x` bot project containing the VEXORA role manager commands.

## Included commands

- `.rc` — creates the predefined VEXORA roles. It does **not** create channels.
- `.cp #channel @Role permission1,permission2 on|off` — changes selected permissions for a role in one channel.
- `.rp @Role permission1,permission2 on|off` — changes selected server-wide permissions for a role.

Examples:

```text
.rc
.cp #general @Member send_messages,attach_files on
.cp #general @Member send_messages off
.rp @Moderator kick_members,manage_messages on
.rp @Member manage_webhooks,manage_roles off
```

Use channel and role mentions for reliable argument parsing, especially when names contain spaces.

## Setup

1. Install Python 3.11 or newer.
2. Open a terminal in this folder.
3. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Copy `.env.example` to `.env` and put your bot token in `DISCORD_TOKEN`.
5. In the Discord Developer Portal, enable **Message Content Intent** (and Server Members Intent if your setup needs it).
6. Invite the bot with the required permissions and run:

   ```bash
   python bot.py
   ```

## Required Discord permissions

- Manage Roles
- Manage Channels (needed for `.cp`)
- View Channels / Send Messages (so it can respond)

The bot's highest role must be above every role it needs to manage. Discord role hierarchy still applies.

## Safety notes

- Only the server owner, an Administrator, or a member with Manage Roles can run the management commands.
- Enabling sensitive server-wide permissions through `.rp` is restricted to the server owner.
- `.rc` skips roles that already exist; it does not overwrite their existing colours or permissions.
- Review the generated roles before assigning them. The predefined Owner role has Administrator permission; keep it restricted to the actual server owner.
- Keep `.env` private. Never share your bot token or upload `.env` to GitHub.

## Project layout

```text
VEXORA_Role_Manager/
├── bot.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── cogs/
    ├── __init__.py
    └── vexora_role_manager.py
```

This ZIP is a complete runnable project for the **role-manager bot**. It is not the entire larger VEXORA all-in-one bot project.
